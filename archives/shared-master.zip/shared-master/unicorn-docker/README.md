1. Install `docker` and `docker-compose`.
2. Execute `./start`.
